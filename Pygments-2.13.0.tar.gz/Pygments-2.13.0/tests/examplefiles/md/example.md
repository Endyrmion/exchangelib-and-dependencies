# this is a header

## this is a 2nd level header

* list item 1
  * list item 1.1
* list item 2
- list item 3

1. numbered list item 1
1. numbered list item 2

- [ ] todo
- [x] done
- [X] done

The following is italic: *italic*
The following is italic: _italic_

The following is not italic: \*italic\*
The following is not italic: \_italic\_

The following is not italic: snake*case*word
The following is not italic: snake_case_word

The following is bold: **bold** **two or more words**
The following is bold: __bold__ __two or more words__

The following is not bold: snake**case**word
The following is not bold: snake__case__word

The following is strikethrough: ~~bold~~
The following is not strikethrough: snake~~case~~word

The following is bold with italics inside: **the next _word_ should have been italics**

> this is a quote

> this is a multiline
> quote string thing

this sentence `has monospace` in it

this sentence @tweets a person about a #topic.

[google](https://google.com/some/path.html)
![Image of Yaktocat](https://octodex.github.com/images/yaktocat.png)

[reference link][id]
[id]: http://example.com/

```
  * this is just unformated
      __text__
```

some other text

```python
from pygments import token
# comment
```

some more text
