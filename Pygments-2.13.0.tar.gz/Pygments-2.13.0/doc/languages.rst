:orphan:

This file is overridden by _templates/languages.html and just exists to
allow the language list to be reliably linked from the documentation
(since its location varies between `make html` and `make dirhtml`).
