Full contributor list
=====================

.. include:: ../../AUTHORS
