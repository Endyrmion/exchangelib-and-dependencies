import oauthlib

oauthlib.set_debug(True)
